package com.mycompany.prog5121_fa1;
import java.util.Scanner;

public class PROG5121_FA1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter First Name: ");
        String first = input.nextLine();
        System.out.print("Enter Last Name: ");
        String last = input.nextLine();
        
        Login login = new Login(first, last);
        
        System.out.println("\nUse these valid examples:");
        System.out.println("Username: Bee_3");
        System.out.println("Password: Beekay@10");
        System.out.println("Cell: +27682858948\n");
        
        System.out.print("Enter Username: ");
        String user = input.nextLine();
        
        System.out.print("Enter Password: ");
        String pass = input.nextLine();
        
        System.out.print("Enter Cell: ");
        String cell = input.nextLine();
        
        String regResult = login.registerUser(user, pass, cell);
        System.out.println(regResult);
        
        if (regResult.equals("User successfully registered.")) {
            System.out.println("\n--- LOGIN ---");
            System.out.print("Enter Username to Login: ");
            String loginUser = input.nextLine();
            System.out.print("Enter Password to Login: ");
            String loginPass = input.nextLine();
            
            System.out.println(login.returnLoginStatus(loginUser, loginPass));
        }
        
    }
}