package com.mycompany.prog5121_fa1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

    Login login = new Login();

    @Test
    public void testUsernameCorrectlyFormatted() {
        assertTrue(login.checkUserName("Bee_3"));
    }

    @Test
    public void testUsernameIncorrectlyFormatted() {
        assertFalse(login.checkUserName("BoikanyoKay"));
    }

    @Test
    public void testPasswordMeetsComplexity() {
        assertTrue(login.checkPasswordComplexity("Beekay@10"));
    }

    @Test
    public void testPasswordDoesNotMeetComplexity() {
        assertFalse(login.checkPasswordComplexity("password"));
    }

    @Test
    public void testCellNumberCorrectlyFormatted() {
        assertTrue(login.checkCellPhoneNumber("+27682858948"));
    }

    @Test
    public void testCellNumberIncorrectlyFormatted() {
        assertFalse(login.checkCellPhoneNumber("0682858948"));
    }

    @Test
    public void testRegisterUserSuccessful() {
        String result = login.registerUser("Bee_3", "Beekay@10", "+27682858948");
        assertEquals("User successfully registered.", result);
    }

    @Test
    public void testRegisterUserFailed() {
        String result = login.registerUser("BeeKay", "password", "0682858948");
        assertNotEquals("User successfully registered.", result);
    }

    @Test
    public void testLoginSuccessful() {
        login.registerUser("Bee_3", "Beekay@10", "+27682858948");
        assertTrue(login.loginUser("Bee_3", "Beekay@10"));
    }

    @Test
    public void testLoginFailed() {
        login.registerUser("Bee_3", "Beekay@10", "+27682858948");
        assertFalse(login.loginUser("Bee_3", "Wrong@123"));
    }

    @Test
    public void testWelcomeMessage() {
        login.registerUser("Bee_3", "Beekay@10", "+27682858948");
        login.loginUser("Bee_3", "Beekay@10");
        String message = login.returnLoginStatus("Boikanyo", "Kay");
        assertTrue(message.contains("Welcome"));
    }
}